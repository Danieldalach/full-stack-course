
        var TheSelectedCoins = [];
        var allCoinsNames = [];
        var allcoinsobarr = [];
        var data1 = [];
    
        //מחיקה מהלוקל סטורג כל 2 דקות
setInterval(() => {
localStorage.removeItem("notes");
console.log(localStorage)
},60000*2 )

debugger

        $(function () {
            debugger
          //check if there LOCAL STORAGE 
            var str = localStorage.getItem("notes");
            if (str) {
                showAllCoins();
            }

        
            else{
             $(".img1").show();
// הורדת כל המטבעות ושמירה בלוקאל סטורג
            let url = "https://api.coingecko.com/api/v3/coins/list";
            $.getJSON(url, function (data1) {
                $(".img1").show();

//SAVE TO LOCAL STORAGE
                var theListJson = JSON.stringify(data1);
                localStorage.setItem("notes", theListJson);
///////////////////////

                str = localStorage.getItem("notes");
                showAllCoins();
             })
             }


                function showAllCoins() {
                 data1 = JSON.parse(str)
                //empty main
                allcoinsobarr = data1;
                $(".hello").html("");
                let mylistcoins = "";
                for (let x = 0; x < 35; x++) {
                    mylistcoins +=
                        `<div class="col-sm-4 data-name="${data1[x].symbol}" class="coin" >
                                <h2>${data1[x].symbol}</h2>
                                <h3>${data1[x].name}</h3>  

                                <button class="btn btn-primary" value="${x}" type="button" data-toggle="collapse" data-target="#collapse${x}" aria-expanded="false" aria-controls="collapse${x}">
                                  More info
                                 </button> 
        <label class="switch" value="${data1[x].symbol}" >
        <input type="checkbox" class="checkbox" id='${data1[x].symbol}' value="${data1[x].symbol}"  >
        <span class="slider round"></span>
        </label>
                                 <div class="collapse"  id="collapse${x}">
                                 <div class="card card-body">
                                </div>
                                </div> 
                                </div> `;

                    allCoinsNames.push(data1[x].id);
                    $(".img1").hide();
                }
                $(".hello").html(mylistcoins)

                 // מידע נוסף מטבעות
                 $(".btn").click(function () {
                    debugger
                    $(".img1").show();
                    
                    var coinNum = $(this).val();
                    var ell = "#collapse" + coinNum
                    // $("#collapse"+coinNum).children().text(allCoinsNames[coinNum])


                    let searchWord = allCoinsNames[coinNum];

                    let url = "https://api.coingecko.com/api/v3/coins/";
                    url = url + searchWord
                    $.getJSON(url, function (data) {
                        debugger
                        //SAVE TO LOCAL STORAGE כאן אני מכניס ללוקל סטורג מטבע אחד בכל לחיצה. כל לחיצה על מטבע אחר דורסת את הלוקל הקודם ומעדכנת את המטבע האחרון שנלחץ בלוקל סטורג
                var theListJson2 = JSON.stringify(data);
                localStorage.setItem("coin1", theListJson2);

            //             //local storage
            // var theListcoinJson = JSON.stringify(data);
            // localStorage.setItem("coinss", theListcoinJson);


                        // $(".card").html("");
                        let inside = "";

                        inside =
                            `<div data-name="${data.id}" class="inside" >
                                <h4>${(data.market_data.current_price.usd).toFixed(3)} $</h4>
                    <h4>${(data.market_data.current_price.eur).toFixed(3)} EUR</h4>
                    <h4>${(data.market_data.current_price.ils).toFixed(3)} ILS</h4> 
                    <img src=${data.image.small}>
                </div> `;
                        $("#collapse" + coinNum).children().html(inside);
                        $(".img1").hide();

                    });
                });
            }

            

            
 //חיפוש לפי שם 
                   $("#search").click(function () {
                       
                    $(".img1").show();
                    debugger
                    let searchWord = $(".input1").val();
                    const result = data1.filter(coin => coin.symbol == searchWord);
                    if(result==""){
                        swal("Could Not Find This Coin","Try again","warning");
                        $(".img1").hide();
                    }
                    else{
                       
                    let OneMylistcoins = ` <div class="col-sm-4 data-name="${result[0].symbol}" class="coin" >
                                <h2>${result[0].symbol}</h2>
                                <h3>${result[0].name}</h3>  

                                <button class="btn2 btn-primary" value="${result[0].name}" type="button" data-toggle="collapse" data-target="#collapse0" aria-expanded="false" aria-controls="collapse0"  onclick="ShowOneCoinDetails()">
                                  More info
                                 </button> 
<label class="switch">
  <input type="checkbox" class="checkbox" value=${result[0].symbol} >
  <span class="slider round"></span>
</label>
                                 <div class="collapse"  id="collapse0">
                                 <div class="card card-body">
                                </div>
                                </div> 
                                </div> `;
                                $(".img1").hide();
                    $(".hello").html(OneMylistcoins);
                    }
                                 //לחיצה על לחצן toggle
                $(".checkbox").click(function () {
                    let Tuggele1 = $(this).is(":checked");
                    if(Tuggele1==true){
                        if(TheSelectedCoins.length<5){
                            TheSelectedCoins.push($(this).val());
                        }
                        else {
                            debugger


                            var dd= this
                            var coinToReplace= $(this).val()
                            $(".close2").click(function () {
                                debugger
                    $(dd).prop('checked', false);
                })
                            // $(this).prop('checked', false);
        $('#myModal').modal('show');
        let modalbody = "";
for (let i = 0; i < TheSelectedCoins.length; i++) {
    modalbody +=
                        `<div >
                        <h5>${TheSelectedCoins[i]}</h5>

         <label class="switch2"  value="${TheSelectedCoins[i]}" >
        <input type="checkbox" class="checkbox1" value="${TheSelectedCoins[i]}" checked >
        <span class="slider round"></span>
        </label>
                        </div>`}

         modalbody+=`<h5 class="replace">  ${coinToReplace} </h5>`               

        $(".modal-body").html(modalbody)

        //לחיצה על לחצן toggle פנימי
$(".checkbox1").click(function () {
                    debugger
                  let Tuggele2 = $(this).is(":checked");
                if(Tuggele2==true){
                TheSelectedCoins.push($(this).val()); 
                        }    
                 else{
                    let removeC= TheSelectedCoins.indexOf($(this).val());
                TheSelectedCoins.splice(removeC,1)
                TheSelectedCoins.push($(dd).val());



$(".close1").trigger("click")


let idd= $(this).val()
$("#"+idd).prop('checked', false);

                           }
                    })
}
}

else{
    debugger
                 let removeC= TheSelectedCoins.indexOf($(this).val());
                 TheSelectedCoins.splice(removeC,1)
        
               
                   }
                })
                })
                   






                //לחיצה על לחצן toggle
                $(".checkbox").click(function () {
                    let Tuggele1 = $(this).is(":checked");
                    if(Tuggele1==true){
                        if(TheSelectedCoins.length<5){
                            TheSelectedCoins.push($(this).val());
                        }
                        else {
                            debugger


                            var dd= this
                            var coinToReplace= $(this).val()
                            $(".close2").click(function () {
                                debugger
                    $(dd).prop('checked', false);
                })
                            // $(this).prop('checked', false);
        $('#myModal').modal('show');
        let modalbody = "";
for (let i = 0; i < TheSelectedCoins.length; i++) {
    modalbody +=
                        `<div >
                        <h5>${TheSelectedCoins[i]}</h5>

         <label class="switch2"  value="${TheSelectedCoins[i]}" >
        <input type="checkbox" class="checkbox1" value="${TheSelectedCoins[i]}" checked >
        <span class="slider round"></span>
        </label>
                        </div>`}

         modalbody+=`<h5 class="replace">  ${coinToReplace} </h5>`               

        $(".modal-body").html(modalbody)

        //לחיצה על לחצן toggle פנימי
$(".checkbox1").click(function () {
                    debugger
                  let Tuggele2 = $(this).is(":checked");
                if(Tuggele2==true){
                TheSelectedCoins.push($(this).val()); 
                        }    
                 else{
                    let removeC= TheSelectedCoins.indexOf($(this).val());
                TheSelectedCoins.splice(removeC,1)
                TheSelectedCoins.push($(dd).val());



$(".close1").trigger("click")

// $(this).attr('checked', false); // Unchecks it
$('#myCheckbox').attr('checked', true); // Checks it

let idd= $(this).val()
$("#"+idd).prop('checked', false);

                           }
                    })
}
}

else{
    debugger
                 let removeC= TheSelectedCoins.indexOf($(this).val());
                 TheSelectedCoins.splice(removeC,1)
        
               
                   }
                })



// $("h1").click(function () {

//     alert(TheSelectedCoins)
//     alert(TheSelectedCoinsJSON)

// });







                    //JSON PARSH:
                    //     var StrCoins = localStorage.getItem("coins");
                    //    if (StrCoins) {
                    //    TheSelectedCoins = JSON.parse(StrCoins)}

                    //                         console.log(TheSelectedCoins)  



                })

            
            
            
           
       

 


    

 //   מידע נוסף למטבע אחד
        function ShowOneCoinDetails() {
            debugger
                        $(".img1").show();
            
            var coinNum = $(".btn2").val();
            var coinNum2 = coinNum.toLowerCase()
            let url = "https://api.coingecko.com/api/v3/coins/";
            url = url + coinNum2
            $.getJSON(url, function (data) {
                debugger
                inside =
                    `<div data-name="${data.id}" class="inside" >
                    <h4>${(data.market_data.current_price.usd).toFixed(3)} $</h4>
                    <h4>${(data.market_data.current_price.eur).toFixed(3)} EUR</h4>
                    <h4>${(data.market_data.current_price.ils).toFixed(3)} ILS</h4>  
                    <img src=${data.image.small}>
                </div> `;
                $(".img1").hide();
                $("#collapse0").children().html(inside);
            });
        }






        function getCurrenciesPage() {
            $.get("project2.html", function (myPageHtml) {
                debugger;
              $("body").html(myPageHtml);
                
            });
        }



        function getReportsPage() {
            $(".img1").show();
            $.get("reports.html", function (myPageHtml) {
                debugger;
                $(".img1").hide();
                $(".gg").html(myPageHtml);
            });
        }

        function getAboutPage() {
            $(".img1").show();
            $.get("about.html", function (myPageHtml) {
                debugger;
                $(".img1").hide();
                $(".gg").html(myPageHtml);
            });
        }


